
package interfaces;

/**
 *
 * @author Andre Mujica
 */
public interface Orden {
    
    public String generarDetalle(Object[][] datos);
    
}
